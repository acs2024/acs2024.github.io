Focus on simplicity and brevity over splendor and sophistication
